# BlinkChat — Simple MVP

Run locally:
```
npm install
npm run seed -w server
npm start
```